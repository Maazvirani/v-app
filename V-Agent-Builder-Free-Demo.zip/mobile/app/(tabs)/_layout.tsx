import { SymbolView } from 'expo-symbols';
import { Tabs } from 'expo-router';
import { Platform } from 'react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown:false,
        tabBarActiveTintColor:'#167A66',
        tabBarInactiveTintColor:'#778397',
        tabBarLabelStyle:{ fontSize:11, fontWeight:'600', marginBottom:Platform.OS==='web'?8:0 },
        tabBarStyle:{ backgroundColor:'#FFFFFF', borderTopColor:'#E7EBF0', height:Platform.OS==='web'?66:74, paddingTop:8, elevation:0 },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title:'Overview',
          tabBarIcon:({color})=><SymbolView name={{ios:'square.grid.2x2.fill',android:'grid_view',web:'grid_view'}} tintColor={color} size={21}/> ,
        }}
      />
      <Tabs.Screen
        name="agents"
        options={{
          title:'My agents',
          tabBarIcon:({color})=><SymbolView name={{ios:'sparkles',android:'auto_awesome',web:'auto_awesome'}} tintColor={color} size={21}/> ,
        }}
      />
      <Tabs.Screen name="connections" options={{ title:'Connections',tabBarIcon:({color})=><SymbolView name={{ios:'point.3.connected.trianglepath.dotted',android:'hub',web:'hub'}} tintColor={color} size={21}/> }}/>
      <Tabs.Screen name="activity" options={{ title:'Activity',tabBarIcon:({color})=><SymbolView name={{ios:'clock.arrow.circlepath',android:'history',web:'history'}} tintColor={color} size={21}/> }}/>
      <Tabs.Screen name="settings" options={{ title:'Settings',tabBarIcon:({color})=><SymbolView name={{ios:'slider.horizontal.3',android:'tune',web:'tune'}} tintColor={color} size={21}/> }}/>
    </Tabs>
  );
}
