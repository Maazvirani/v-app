import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { WorkspaceProvider } from '@/lib/Workspace';

export { ErrorBoundary } from 'expo-router';

export default function RootLayout() {
  return <WorkspaceProvider><StatusBar style="dark" /><Stack screenOptions={{ headerShown:false, contentStyle:{ backgroundColor:'#F5F7FA' } }} /></WorkspaceProvider>;
}
