let token: string | null = null;
export async function getToken() { return token; }
export async function setToken(value: string | null) { token = value; }
