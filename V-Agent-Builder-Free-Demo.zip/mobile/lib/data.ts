export type Agent = { id:string; name:string; description:string; instructions:string; model:string; status:'active'|'paused'|'draft'; scheduleMinutes:number; source:string; createdAt:string; nextRunAt?:string|null };
export type AgentRun = { id:string; agentId:string; agentName?:string; input:string; output:string; status:'running'|'succeeded'|'failed'; errorCode?:string; durationMs?:number; createdAt:string };
export type Connection = { provider:string; label:string; connectedAt:string };
export const demoAgents: Agent[] = [
  { id:'demo-1',name:'Inbox copilot',description:'Keeps customer replies moving with clear, warm answers.',instructions:'Read a customer request, identify what they need, and draft a helpful response. Ask for missing information.',model:'gpt-5-mini',status:'active',scheduleMinutes:60,source:'whatsapp',createdAt:new Date().toISOString() },
  { id:'demo-2',name:'Weekly signal brief',description:'Turns team notes into a short weekly briefing.',instructions:'Summarize the key updates, decisions, risks, and next steps from the supplied notes.',model:'gpt-5-mini',status:'active',scheduleMinutes:1440,source:'schedule',createdAt:new Date().toISOString() },
  { id:'demo-3',name:'Research assistant',description:'Collects questions and prepares a first research outline.',instructions:'Clarify the research question and return a structured, evidence-aware outline.',model:'gpt-4.1-mini',status:'paused',scheduleMinutes:60,source:'manual',createdAt:new Date().toISOString() },
];
export const demoRuns: AgentRun[] = [
  { id:'run-1',agentId:'demo-1',agentName:'Inbox copilot',input:'A customer wants to change their delivery address.',output:'Draft reply: “Of course. Please share your order number and the new delivery address, and I’ll help update it.”',status:'succeeded',durationMs:1840,createdAt:new Date(Date.now()-22*60_000).toISOString() },
  { id:'run-2',agentId:'demo-2',agentName:'Weekly signal brief',input:'Scheduled check-in',output:'Two product updates shipped. The onboarding refresh is ready for review. Follow up on the open billing question.',status:'succeeded',durationMs:2190,createdAt:new Date(Date.now()-3*60*60_000).toISOString() },
];
export const catalog = [
  { id:'whatsapp',name:'WhatsApp Business',type:'Messaging',detail:'Cloud API · business account',state:'Setup required',mark:'W',tone:'#25A776' },
  { id:'openai',name:'OpenAI',type:'AI models',detail:'GPT models · API key',state:'Add key',mark:'O',tone:'#161616' },
  { id:'anthropic',name:'Anthropic Claude',type:'AI models',detail:'Claude models · API key',state:'Add key',mark:'C',tone:'#C87955' },
  { id:'gemini',name:'Google Gemini',type:'AI models',detail:'Gemini models · API key',state:'Add key',mark:'G',tone:'#4285F4' },
  { id:'google',name:'Google Workspace',type:'Productivity',detail:'Gmail · Calendar · Drive',state:'Coming soon',mark:'G',tone:'#4285F4' },
  { id:'slack',name:'Slack',type:'Messaging',detail:'OAuth · channels and DMs',state:'Coming soon',mark:'S',tone:'#8C5AF5' },
  { id:'discord',name:'Discord',type:'Messaging',detail:'Bot connection · servers',state:'Coming soon',mark:'D',tone:'#5865F2' },
  { id:'telegram',name:'Telegram',type:'Messaging',detail:'Bot API · messages',state:'Coming soon',mark:'T',tone:'#299ED8' },
  { id:'notion',name:'Notion',type:'Productivity',detail:'OAuth · pages and databases',state:'Coming soon',mark:'N',tone:'#28292C' },
];
