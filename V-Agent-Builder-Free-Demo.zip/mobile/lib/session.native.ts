import * as SecureStore from 'expo-secure-store';
export async function getToken() { return SecureStore.getItemAsync('vagent_session'); }
export async function setToken(value: string | null) {
  if (value) await SecureStore.setItemAsync('vagent_session', value, { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY });
  else await SecureStore.deleteItemAsync('vagent_session');
}
