import { Platform } from 'react-native';
import { getToken } from './session';

const BASE_URL = process.env.EXPO_PUBLIC_API_URL?.replace(/\/$/, '') || (Platform.OS === 'web' && typeof window !== 'undefined' ? window.location.origin : '');
export class ApiError extends Error { code?: string; status?: number; constructor(message: string, code?: string, status?: number) { super(message); this.code=code; this.status=status; } }
export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = await getToken();
  let response: Response;
  try {
    response = await fetch(`${BASE_URL}${path}`, {
      ...options,
      credentials: Platform.OS === 'web' ? 'include' : 'omit',
      headers: { 'content-type':'application/json', ...(Platform.OS === 'web' ? {} : { 'x-client-platform':'native' }), ...(token ? { authorization:`Bearer ${token}` } : {}), ...options.headers },
    });
  } catch {
    throw new ApiError('Sign-in and saving are unavailable in this preview. Use the demo workspace or open your hosted app.', 'SERVER_UNREACHABLE');
  }
  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    throw new ApiError('Sign-in and saving are unavailable in this preview. Use the demo workspace or open your hosted app.', 'SERVER_NOT_CONFIGURED', response.status);
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = payload.code === 'INTERNAL_ERROR'
      ? 'The V-Agent server ran into a problem while handling this request. Please retry; if it continues, contact your workspace administrator.'
      : payload.error || 'The server could not complete this request.';
    throw new ApiError(message, payload.code, response.status);
  }
  return payload as T;
}
