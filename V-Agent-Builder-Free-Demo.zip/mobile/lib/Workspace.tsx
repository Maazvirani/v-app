import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { Alert, Platform } from 'react-native';
import { api, ApiError } from './api';
import { Agent, AgentRun, Connection, demoAgents, demoRuns } from './data';
import { getToken, setToken } from './session';

type WorkspaceValue = {
  ready:boolean; demo:boolean; email:string; agents:Agent[]; runs:AgentRun[]; connections:Connection[]; serverNotice:string;
  beginDemo:()=>void; signIn:(email:string,password:string,signup:boolean)=>Promise<void>; signOut:()=>Promise<void>;
  userId:string; createAgent:(values:Partial<Agent>)=>Promise<Agent>; updateAgent:(id:string,values:Partial<Agent>)=>Promise<void>; runAgent:(id:string,input:string)=>Promise<AgentRun>; addAIKey:(provider:'openai'|'anthropic'|'gemini',label:string,key:string)=>Promise<void>; addWhatsApp:(credentials:{phoneNumberId:string;accessToken:string;appSecret:string;verifyToken:string})=>Promise<{label:string;webhookUrl:string;verifyToken:string}>; removeConnection:(provider:string)=>Promise<void>; refresh:()=>Promise<void>;
};
const WorkspaceContext=createContext<WorkspaceValue | null>(null);
const notice=(message:string)=> Platform.OS==='web' ? window.alert(message) : Alert.alert('V-Agent Builder',message);

export function WorkspaceProvider({ children }: { children:React.ReactNode }) {
  const [ready,setReady]=useState(false); const [demo,setDemo]=useState(false); const [email,setEmail]=useState('');const [userId,setUserId]=useState('');const [serverNotice,setServerNotice]=useState('');
  const [agents,setAgents]=useState<Agent[]>([]); const [runs,setRuns]=useState<AgentRun[]>([]); const [connections,setConnections]=useState<Connection[]>([]);
  const refresh=async()=>{
    try {
      const [agentData,runData,connectionData]=await Promise.all([api<{agents:Agent[]}>('/api/agents'),api<{runs:AgentRun[]}>('/api/runs'),api<{connections:Connection[]}>('/api/connections')]);
      setAgents(agentData.agents);setRuns(runData.runs);setConnections(connectionData.connections);setServerNotice('');
    } catch(error) { setServerNotice(error instanceof Error?error.message:'V-Agent could not load your workspace. Check the server connection and retry.'); throw error; }
  };
  useEffect(()=>{ let mounted=true; (async()=>{ try { await getToken(); const result=await api<{user:{id:string;email:string}}>('/api/auth/me'); if(mounted){setEmail(result.user.email);setUserId(result.user.id);try{await refresh();}catch{}} } catch { await setToken(null); } finally {if(mounted)setReady(true);} })(); return()=>{mounted=false;}; },[]);
  const beginDemo=()=>{setDemo(true);setServerNotice('');setEmail('demo@vagent.local');setUserId('');setAgents(demoAgents);setRuns(demoRuns);setConnections([{provider:'whatsapp',label:'Demo business account',connectedAt:new Date().toISOString()}]);};
  const signIn=async(address:string,password:string,signup:boolean)=>{
    const response=await api<{user:{id:string;email:string};token?:string}>(`/api/auth/${signup?'signup':'login'}`,{method:'POST',body:JSON.stringify({email:address,password})});
    await setToken(response.token || null);setEmail(response.user.email);setUserId(response.user.id);setDemo(false);
    try { await refresh(); } catch { setAgents([]);setRuns([]);setConnections([]); }
  };
  const signOut=async()=>{try{await api('/api/auth/logout',{method:'POST'});}catch{} await setToken(null);setDemo(false);setEmail('');setUserId('');setAgents([]);setRuns([]);setConnections([]);setServerNotice('');};
  const createAgent=async(values:Partial<Agent>)=>{
    if(demo){const agent:Agent={id:`demo-${Date.now()}`,name:values.name||'New agent',description:values.description||'',instructions:values.instructions||'',model:values.model||'gpt-5-mini',status:values.status||'draft',scheduleMinutes:values.scheduleMinutes||60,source:'Manual',createdAt:new Date().toISOString()};setAgents(current=>[agent,...current]);return agent;}
    const result=await api<{agent:Agent}>('/api/agents',{method:'POST',body:JSON.stringify(values)});setAgents(current=>[result.agent,...current]);return result.agent;
  };
  const updateAgent=async(id:string,values:Partial<Agent>)=>{
    if(demo){setAgents(current=>current.map(item=>item.id===id?{...item,...values}:item));return;}
    const result=await api<{agent:Agent}>(`/api/agents/${id}`,{method:'PATCH',body:JSON.stringify(values)});setAgents(current=>current.map(item=>item.id===id?result.agent:item));
  };
  const runAgent=async(id:string,input:string)=>{
    if(demo){const agent=agents.find(item=>item.id===id);const run:AgentRun={id:`run-${Date.now()}`,agentId:id,agentName:agent?.name,input,output:`This is a preview run for ${agent?.name||'your agent'}. Connect an AI key and sign in to save real outputs to your server.`,status:'succeeded',durationMs:1200,createdAt:new Date().toISOString()};setRuns(current=>[run,...current]);return run;}
    const result=await api<{run:AgentRun}>(`/api/agents/${id}/run`,{method:'POST',body:JSON.stringify({input})});setRuns(current=>[result.run,...current]);return result.run;
  };
  const addAIKey=async(provider:'openai'|'anthropic'|'gemini',label:string,key:string)=>{if(demo)throw new ApiError('Create an account to securely store an API key.');await api(`/api/connections/ai/${provider}`,{method:'POST',body:JSON.stringify({label,apiKey:key})});await refresh();};
  const addWhatsApp=async(credentials:{phoneNumberId:string;accessToken:string;appSecret:string;verifyToken:string})=>{if(demo)throw new ApiError('Create an account to connect WhatsApp.');const result=await api<{connection:{label:string};webhookUrl:string;verifyToken:string}>('/api/connections/whatsapp',{method:'POST',body:JSON.stringify(credentials)});await refresh();return {label:result.connection.label,webhookUrl:result.webhookUrl,verifyToken:result.verifyToken};};
  const removeConnection=async(provider:string)=>{if(demo){setConnections([]);return;}await api(`/api/connections/${provider}`,{method:'DELETE'});await refresh();};
  const value=useMemo(()=>({ready,demo,email,userId,agents,runs,connections,serverNotice,beginDemo,signIn,signOut,createAgent,updateAgent,runAgent,addAIKey,addWhatsApp,removeConnection,refresh}),[ready,demo,email,userId,agents,runs,connections,serverNotice]);
  return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>;
}
export function useWorkspace(){const value=useContext(WorkspaceContext);if(!value)throw new Error('WorkspaceProvider is missing.');return value;}
