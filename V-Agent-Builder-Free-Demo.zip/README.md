# V-Agent Builder

V-Agent Builder is a self-hosted workspace for creating focused AI agents. It includes a shared Expo app for web, iOS, and Android, plus a Node.js API and a PostgreSQL database that can run on a server you control.

## What works in this build

- Create an account with email and password, sign in, and sign out.
- Create agents with a name, description, instructions, model, and run schedule.
- Run an agent with your own input and save its output and run history.
- Activate an agent for scheduled runs on the server or inbound WhatsApp replies, or pause it at any time. Scheduled agents produce saved outputs; WhatsApp-triggered agents can send replies to the message sender.
- Add OpenAI, Anthropic Claude, and Google Gemini API keys in Connections. Per-user keys are encrypted in the database with AES-256-GCM. A server-wide OpenAI key can also be supplied as `OPENAI_API_KEY`.
- Preview the interface without a server using the clearly labelled demo workspace.

The account screen opens with **Explore the demo workspace**, so the preview is usable without hosting an API. Real sign-in and saving work after deployment. See [README_FREE_HOSTING.md](README_FREE_HOSTING.md) for a browser-based free-tier demo deployment guide.

The schedule worker checks every 15 seconds and runs one due task at a time. The agent minimum schedule is 15 minutes. Scheduled model usage can incur provider costs.

WhatsApp can verify a Meta phone-number token, store its credentials encrypted, verify webhook signatures, queue inbound text messages, run an active WhatsApp-triggered agent, and send its reply. Configure an HTTPS deployment and subscribe the Meta webhook to `messages` first. Messages outside Meta's customer-service window may require approved templates; this version replies only to incoming text messages.

## Start the self-hosted web app

Prerequisites: Node.js 24 or newer and Docker Compose.

From this directory:

```powershell
npm run setup
npm start
```

Open [http://localhost:4100](http://localhost:4100). The setup command creates a private `.env` with a random database password and a separate 256-bit encryption key. The Docker database is only reachable from the app container. Data is stored in the `vagent-data` volume.

To stop the containers while keeping database data:

```powershell
npm run stop
```

To remove the database volume as well, run `docker compose down --volumes`; this permanently deletes accounts, agents, run history, and saved connections.

For a public server, set `PUBLIC_APP_URL` in `.env` to the final HTTPS origin, put the app behind an HTTPS reverse proxy, restrict server access, and keep both `.env` and `.env.local` out of source control. Back up the PostgreSQL volume and `APP_ENCRYPTION_KEY` separately. Without that key, encrypted app credentials cannot be recovered. The included Docker service listens on port 4100; configure your proxy to forward that port and enable TLS.

Signed-in workspaces can add their own OpenAI, Anthropic, and Gemini keys in **Connections**. Keys are stored encrypted on the server and never bundled into web or mobile code. Agent model IDs are editable, so you can select a model your provider account has access to.

## Web, iOS, and Android development

The web client is served by the Docker app. For local app development, run the API and database with Docker, then start Expo in a second terminal:

```powershell
cd mobile
$env:EXPO_PUBLIC_API_URL = "http://localhost:4100"
npm run web
```

For a device on your Wi-Fi network, set `EXPO_PUBLIC_API_URL` to the server's LAN address, such as `http://192.168.1.20:4100`, before starting Expo. Use HTTPS for any public deployment. Native session tokens use the device secure storage; web sessions use an HTTP-only cookie.

The Expo project is configured for store builds with `mobile/eas.json`. Before building native store binaries, choose the permanent API hostname and set `EXPO_PUBLIC_API_URL` in the EAS build environment. You also need an Expo account, an Apple Developer account for App Store builds, and a Google Play Console account for Play Store submission. Those accounts and store submissions are not configured from this workspace.

```powershell
cd mobile
npx eas-cli@latest build --platform all --profile production
```

## Integrations

V-Agent uses email and password only for its own account. External applications do not share a universal email sign-in. Each provider needs its own OAuth consent flow, API scopes, and (for some services) provider approval.

OpenAI agent runs and WhatsApp Business inbound text replies are implemented. Connecting WhatsApp still requires your Meta app, business phone number, access token, app secret, public HTTPS server, and webhook subscription. Google Workspace, Slack, Discord, Telegram, and Notion are listed as planned connectors. The catalog is extensible; it does not claim that every app is already connected.

## Security notes

- Passwords are stored as salted `scrypt` hashes; raw passwords are not stored.
- Session tokens are random, stored as hashes in PostgreSQL, and expire after 30 days. Web cookies are HTTP-only and SameSite strict; production cookies are Secure.
- Per-user API credentials are encrypted with AES-256-GCM using a server-only key.
- Agent inputs and outputs are private to their account in API queries.
- The API has request size limits, origin checks for browser writes, and a sign-in attempt limit.
- This starter does not include email verification, password-reset delivery, team membership, billing, a public OAuth app directory, or formal security certification. Add and test those before inviting public users.

## App structure

- `mobile/` — Expo Router app shared by Android, iOS, and web.
- `server/` — Node.js API, agent scheduler, and PostgreSQL schema.
- `docker-compose.yml` — self-hosted app and database.
