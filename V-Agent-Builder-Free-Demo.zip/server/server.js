import { createServer } from 'node:http';
import { createHash, createHmac, randomBytes, scryptSync, timingSafeEqual, randomUUID, createCipheriv, createDecipheriv } from 'node:crypto';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

const { Pool } = pg;
const ROOT = fileURLToPath(new URL('.', import.meta.url));
const PORT = Number(process.env.PORT || 4100);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10, ssl: process.env.PGSSLMODE === 'require' ? { rejectUnauthorized: true } : undefined });
const apiKey = process.env.OPENAI_API_KEY?.trim();
const encKey = process.env.APP_ENCRYPTION_KEY;
const publicUrl = (process.env.PUBLIC_APP_URL || '').replace(/\/$/, '');
const whatsappVersion = process.env.WHATSAPP_GRAPH_VERSION || 'v23.0';
const webRoot = join(ROOT, '..', 'mobile', 'dist');
const supportedProviders = new Set(['openai', 'anthropic', 'gemini']);
const defaultModels = { openai:'gpt-5.6-luna', anthropic:'claude-sonnet-5-5', gemini:'gemini-3.8-flash' };
const loginAttempts = new Map();
const MIME = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json; charset=utf-8', '.png':'image/png', '.jpg':'image/jpeg', '.svg':'image/svg+xml', '.ico':'image/x-icon', '.woff2':'font/woff2' };

if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required.');
if (!encKey || Buffer.from(encKey, 'base64').length !== 32) throw new Error('APP_ENCRYPTION_KEY must be a base64 encoded 32-byte key. Run npm run setup from the app directory.');

const json = (res, status, body, extra = {}) => {
  const data = JSON.stringify(body);
  res.writeHead(status, { 'content-type':'application/json; charset=utf-8', 'content-length':Buffer.byteLength(data), 'cache-control':'no-store', ...extra });
  res.end(data);
};
const fail = (res, status, message, code) => json(res, status, { error: message, code });
const safeEqual = (a, b) => { const left = Buffer.from(String(a)); const right = Buffer.from(String(b)); return left.length === right.length && timingSafeEqual(left, right); };
const tokenDigest = value => createHash('sha256').update(value).digest('hex');
const seal = value => {
  const iv = randomBytes(12); const cipher = createCipheriv('aes-256-gcm', Buffer.from(encKey, 'base64'), iv);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), ciphertext]);
};
const unseal = value => {
  const bytes = Buffer.from(value); const decipher = createDecipheriv('aes-256-gcm', Buffer.from(encKey, 'base64'), bytes.subarray(0, 12));
  decipher.setAuthTag(bytes.subarray(12, 28));
  return JSON.parse(Buffer.concat([decipher.update(bytes.subarray(28)), decipher.final()]).toString('utf8'));
};

async function bodyOf(req) {
  const chunks = []; let size = 0;
  for await (const chunk of req) { size += chunk.length; if (size > 1_000_000) throw Object.assign(new Error('Request is too large.'), { status:413 }); chunks.push(chunk); }
  const raw = Buffer.concat(chunks);
  if (req.headers['content-type']?.includes('application/json')) return { raw, value: raw.length ? JSON.parse(raw.toString('utf8')) : {} };
  return { raw, value: {} };
}
function cookieValue(req, name) {
  const part = (req.headers.cookie || '').split(';').map(x => x.trim()).find(x => x.startsWith(`${name}=`));
  return part ? decodeURIComponent(part.slice(name.length + 1)) : '';
}
function sessionCookie(token, clear = false) {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  return `vagent_session=${clear ? '' : encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${clear ? 0 : 2592000}${secure}`;
}
function checkOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  if (publicUrl && origin === publicUrl) return true;
  return origin === `http://${req.headers.host}` || origin === `https://${req.headers.host}`;
}
async function authenticate(req) {
  const bearer = /^Bearer\s+(.+)$/i.exec(req.headers.authorization || '')?.[1];
  const token = bearer || cookieValue(req, 'vagent_session');
  if (!token || token.length > 256) return null;
  const { rows } = await pool.query('SELECT u.id, u.email FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at > now()', [tokenDigest(token)]);
  return rows[0] || null;
}
function issueSession(userId) {
  const token = randomBytes(32).toString('base64url');
  return pool.query('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES($1,$2,now()+interval \'30 days\')', [tokenDigest(token), userId]).then(() => token);
}
function clientToken(req, token, user) {
  const mobile = req.headers['x-client-platform'] === 'native';
  return mobile ? jsonWithCookie(user, { token }) : jsonWithCookie(user, {});
  function jsonWithCookie(payload, auth) {
    return { body: { user: payload, ...auth }, headers: { 'set-cookie': sessionCookie(token) } };
  }
}
function modelForAgent(value) {
  const raw = String(value || '');
  const separator = raw.indexOf(':');
  const provider = separator > 0 ? raw.slice(0, separator) : 'openai';
  const model = separator > 0 ? raw.slice(separator + 1) : raw;
  if (!supportedProviders.has(provider) || !/^[A-Za-z0-9._:-]{2,100}$/.test(model)) return { provider:'openai', model:defaultModels.openai };
  return { provider, model:model || defaultModels[provider] };
}
async function runModel(agent, input, userId) {
  const { provider, model } = modelForAgent(agent.model);
  const { rows } = await pool.query('SELECT encrypted_credentials FROM connections WHERE user_id=$1 AND provider=$2 ORDER BY connected_at DESC LIMIT 1', [userId, provider]);
  const userKey = rows[0] ? unseal(rows[0].encrypted_credentials).apiKey : '';
  const key = userKey || (provider === 'openai' ? apiKey : '');
  if (!key) throw Object.assign(new Error(`Add a ${provider === 'anthropic' ? 'Claude' : provider === 'gemini' ? 'Gemini' : 'OpenAI'} API key in Connections to run this agent.`), { code:'AI_KEY_MISSING' });
  const instructions = `${agent.instructions}\n\nAgent description: ${agent.description || 'No description provided.'}`;
  const prompt = input || 'Run your scheduled task. Return a concise status update.';
  let url, headers, body;
  if (provider === 'anthropic') {
    url = 'https://api.anthropic.com/v1/messages';
    headers = { 'x-api-key':key, 'anthropic-version':'2023-06-01', 'content-type':'application/json' };
    body = { model, max_tokens:2048, system:instructions, messages:[{ role:'user', content:prompt }] };
  } else if (provider === 'gemini') {
    url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
    headers = { 'x-goog-api-key':key, 'content-type':'application/json' };
    body = { systemInstruction:{ parts:[{ text:instructions }] }, contents:[{ role:'user', parts:[{ text:prompt }] }], generationConfig:{ maxOutputTokens:2048 } };
  } else {
    url = 'https://api.openai.com/v1/responses';
    headers = { authorization:`Bearer ${key}`, 'content-type':'application/json' };
    body = { model, instructions, input:prompt };
  }
  const response = await fetch(url, { method:'POST', headers, body:JSON.stringify(body), signal:AbortSignal.timeout(60_000) });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = result.error?.message || result.message || `Provider returned ${response.status}.`;
    throw Object.assign(new Error(detail), { code:'AI_PROVIDER_ERROR' });
  }
  const text = provider === 'anthropic'
    ? (result.content || []).filter(item => item.type === 'text').map(item => item.text).join('\n').trim()
    : provider === 'gemini'
      ? (result.candidates?.[0]?.content?.parts || []).map(item => item.text || '').join('\n').trim()
      : (result.output || []).flatMap(item => item.content || []).filter(item => item.type === 'output_text').map(item => item.text).join('\n').trim();
  if (!text) throw Object.assign(new Error('The model returned no text output.'), { code:'AI_EMPTY_OUTPUT' });
  return text.slice(0, 30_000);
}
async function executeAgent(agent, userId, input) {
  const runId = randomUUID(); const started = Date.now();
  await pool.query('INSERT INTO runs(id,agent_id,user_id,input,status) VALUES($1,$2,$3,$4,$5)', [runId, agent.id, userId, input || '', 'running']);
  try {
    const output = await runModel(agent, input, userId);
    await pool.query('UPDATE runs SET output=$1,status=$2,duration_ms=$3 WHERE id=$4', [output, 'succeeded', Date.now() - started, runId]);
    return { id:runId, output, status:'succeeded', durationMs:Date.now() - started };
  } catch (error) {
    const message = String(error.message || 'Agent run failed.').slice(0, 800);
    await pool.query('UPDATE runs SET output=$1,status=$2,error_code=$3,duration_ms=$4 WHERE id=$5', [message, 'failed', error.code || 'RUN_FAILED', Date.now() - started, runId]);
    throw Object.assign(error, { runId });
  }
}
const rowAgent = row => ({ id:row.id, name:row.name, description:row.description, instructions:row.instructions, model:row.model, status:row.status, scheduleMinutes:row.schedule_minutes, source:row.source, createdAt:row.created_at, nextRunAt:row.next_run_at });
const rowRun = row => ({ id:row.id, agentId:row.agent_id, input:row.input, output:row.output, status:row.status, errorCode:row.error_code, durationMs:row.duration_ms, createdAt:row.created_at });

async function route(req, res, requestUrl) {
  const path = requestUrl.pathname;
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'access-control-allow-methods':'GET,POST,PATCH,DELETE,OPTIONS', 'access-control-allow-headers':'content-type,authorization,x-client-platform', 'access-control-max-age':'600' }); return res.end(); }
  if (req.method === 'GET' && path === '/api/health') { await pool.query('SELECT 1'); return json(res, 200, { ok:true, service:'v-agent-builder', runtime:'self-hosted', aiConfigured:Boolean(apiKey) }); }
  if (!path.startsWith('/api/')) return serveWeb(path, res);
  if (['POST','PATCH','DELETE'].includes(req.method) && !checkOrigin(req)) return fail(res, 403, 'Request origin is not allowed.', 'ORIGIN_DENIED');
  let body = {}; let raw = Buffer.alloc(0);
  if (['POST','PATCH','PUT'].includes(req.method)) { try { ({ value:body, raw } = await bodyOf(req)); } catch(error) { return fail(res, error.status || 400, error.status ? error.message : 'Invalid JSON request.','INVALID_BODY'); } }

  const webhookRoute=/^\/api\/webhooks\/whatsapp\/([0-9a-f-]+)$/i.exec(path);
  if (webhookRoute) {
    const ownerId=webhookRoute[1]; const connection=await pool.query('SELECT encrypted_credentials FROM connections WHERE user_id=$1 AND provider=$2 ORDER BY connected_at DESC LIMIT 1',[ownerId,'whatsapp']);
    if (!connection.rows[0]) return fail(res,404,'WhatsApp connection not found.','CONNECTION_NOT_FOUND');
    const credentials=unseal(connection.rows[0].encrypted_credentials);
    if (req.method==='GET') {
      const mode=requestUrl.searchParams.get('hub.mode') || requestUrl.searchParams.get('hub[mode]');
      const verify=requestUrl.searchParams.get('hub.verify_token') || requestUrl.searchParams.get('hub[verify_token]');
      const challenge=requestUrl.searchParams.get('hub.challenge') || requestUrl.searchParams.get('hub[challenge]');
      if (mode!=='subscribe' || !safeEqual(verify || '',credentials.verifyToken)) return fail(res,403,'Webhook verification was not accepted.','WEBHOOK_VERIFY_FAILED');
      res.writeHead(200,{'content-type':'text/plain; charset=utf-8','cache-control':'no-store'});return res.end(String(challenge || ''));
    }
    if (req.method==='POST') {
      const signature=String(req.headers['x-hub-signature-256'] || ''); const expected=`sha256=${createHmac('sha256',credentials.appSecret).update(raw).digest('hex')}`;
      if (!safeEqual(signature,expected)) return fail(res,403,'Webhook signature is invalid.','WEBHOOK_SIGNATURE_INVALID');
      const messages=(body.entry || []).flatMap(entry=>entry.changes || []).flatMap(change=>change.value?.metadata?.phone_number_id===credentials.phoneNumberId ? change.value?.messages || [] : []);
      for (const message of messages) {
        if (!message.id || !message.from || message.type!=='text' || !message.text?.body) continue;
        await pool.query('INSERT INTO whatsapp_events(event_id,user_id,sender,message) VALUES($1,$2,$3,$4) ON CONFLICT(event_id) DO NOTHING',[message.id,ownerId,String(message.from).slice(0,32),String(message.text.body).slice(0,8000)]);
      }
      return json(res,200,{received:true});
    }
    return fail(res,405,'Webhook method is not supported.','METHOD_NOT_ALLOWED');
  }

  if (req.method === 'POST' && (path === '/api/auth/signup' || path === '/api/auth/login')) {
    const ip = req.socket.remoteAddress || 'unknown'; const now = Date.now(); const attempts = (loginAttempts.get(ip) || []).filter(time => now - time < 600_000);
    if (attempts.length >= 12) return fail(res, 429, 'Too many sign-in attempts. Try again in a few minutes.', 'RATE_LIMITED');
    attempts.push(now); loginAttempts.set(ip, attempts);
    const email = String(body.email || '').trim().toLowerCase(); const password = String(body.password || '');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return fail(res, 400, 'Enter a valid email address.', 'INVALID_EMAIL');
    if (path.endsWith('signup') && password.length < 12) return fail(res, 400, 'Use a password with at least 12 characters.', 'WEAK_PASSWORD');
    if (password.length > 256) return fail(res, 400, 'Password is too long.', 'INVALID_PASSWORD');
    let user;
    try {
      if (path.endsWith('signup')) {
        const salt = randomBytes(16).toString('hex'); const hash = scryptSync(password, salt, 64).toString('hex');
        const result = await pool.query('INSERT INTO users(email,password_hash) VALUES($1,$2) RETURNING id,email', [email, `${salt}:${hash}`]); user = result.rows[0];
      } else {
        const result = await pool.query('SELECT id,email,password_hash FROM users WHERE email=$1', [email]);
        const found = result.rows[0]; const [salt, hash] = (found?.password_hash || '00:').split(':');
        const candidate = scryptSync(password, salt, 64); if (!found || !safeEqual(candidate.toString('hex'), hash)) return fail(res, 401, 'Email or password is incorrect.', 'INVALID_CREDENTIALS');
        user = { id:found.id, email:found.email };
      }
    } catch(error) { if (error.code === '23505') return fail(res, 409, 'An account with this email already exists.', 'EMAIL_EXISTS'); throw error; }
    const token = await issueSession(user.id); const result = clientToken(req, token, user); return json(res, 200, result.body, result.headers);
  }
  if (req.method === 'POST' && path === '/api/auth/logout') {
    const user = await authenticate(req); const token = /^Bearer\s+(.+)$/i.exec(req.headers.authorization || '')?.[1] || cookieValue(req, 'vagent_session');
    if (token) await pool.query('DELETE FROM sessions WHERE token_hash=$1', [tokenDigest(token)]);
    return json(res, 200, { ok:true }, { 'set-cookie':sessionCookie('',true) });
  }
  const user = await authenticate(req);
  if (req.method === 'GET' && path === '/api/auth/me') return user ? json(res, 200, { user }) : fail(res, 401, 'Sign in to continue.', 'UNAUTHENTICATED');
  if (!user) return fail(res, 401, 'Sign in to continue.', 'UNAUTHENTICATED');

  if (req.method === 'GET' && path === '/api/agents') {
    const { rows } = await pool.query('SELECT * FROM agents WHERE user_id=$1 ORDER BY created_at DESC', [user.id]); return json(res, 200, { agents:rows.map(rowAgent) });
  }
  if (req.method === 'POST' && path === '/api/agents') {
    const name = String(body.name || '').trim(); const instructions = String(body.instructions || '').trim(); const description = String(body.description || '').trim();
    if (name.length < 2 || name.length > 80) return fail(res, 400, 'Agent name must be 2–80 characters.', 'INVALID_AGENT_NAME');
    if (instructions.length < 8 || instructions.length > 8000) return fail(res, 400, 'Add instructions between 8 and 8,000 characters.', 'INVALID_INSTRUCTIONS');
    const model = `${modelForAgent(body.model).provider}:${modelForAgent(body.model).model}`; const schedule = Math.max(15, Math.min(10080, Number(body.scheduleMinutes) || 60));
    const status = ['active','paused','draft'].includes(body.status) ? body.status : 'draft'; const source=['manual','schedule','whatsapp'].includes(body.source)?body.source:'manual';
    const { rows } = await pool.query('INSERT INTO agents(user_id,name,description,instructions,model,status,schedule_minutes,next_run_at,source) VALUES($1,$2,$3,$4,$5,$6,$7,CASE WHEN $6=\'active\' AND $8=\'schedule\' THEN now()+make_interval(mins=>$7) ELSE NULL END,$8) RETURNING *', [user.id,name,description.slice(0,500),instructions,model,status,schedule,source]);
    return json(res, 201, { agent:rowAgent(rows[0]) });
  }
  const agentPath = /^\/api\/agents\/([0-9a-f-]+)(?:\/(run|runs))?$/.exec(path);
  if (agentPath) {
    const [, id, action] = agentPath; const { rows } = await pool.query('SELECT * FROM agents WHERE id=$1 AND user_id=$2', [id,user.id]); const agent = rows[0];
    if (!agent) return fail(res, 404, 'Agent not found.', 'AGENT_NOT_FOUND');
    if (req.method === 'GET' && !action) return json(res, 200, { agent:rowAgent(agent) });
    if (req.method === 'PATCH' && !action) {
      const name = String(body.name ?? agent.name).trim(); const description = String(body.description ?? agent.description).slice(0,500); const instructions = String(body.instructions ?? agent.instructions).trim();
      const status = ['active','paused','draft'].includes(body.status) ? body.status : agent.status; const model = body.model ? `${modelForAgent(body.model).provider}:${modelForAgent(body.model).model}` : agent.model; const schedule = Math.max(15, Math.min(10080, Number(body.scheduleMinutes) || agent.schedule_minutes));
      if (name.length < 2 || instructions.length < 8) return fail(res, 400, 'Provide an agent name and instructions.', 'INVALID_AGENT');
      const update = await pool.query('UPDATE agents SET name=$1,description=$2,instructions=$3,model=$4,status=$5,schedule_minutes=$6,next_run_at=CASE WHEN $5=\'active\' AND source=\'schedule\' THEN coalesce(next_run_at,now()+make_interval(mins=>$6)) ELSE NULL END,updated_at=now() WHERE id=$7 AND user_id=$8 RETURNING *', [name,description,instructions,model,status,schedule,id,user.id]);
      return json(res, 200, { agent:rowAgent(update.rows[0]) });
    }
    if (req.method === 'DELETE' && !action) { await pool.query('DELETE FROM agents WHERE id=$1 AND user_id=$2',[id,user.id]); return json(res,200,{ok:true}); }
    if (req.method === 'GET' && action === 'runs') { const runs=await pool.query('SELECT * FROM runs WHERE agent_id=$1 AND user_id=$2 ORDER BY created_at DESC LIMIT 40',[id,user.id]); return json(res,200,{runs:runs.rows.map(rowRun)}); }
    if (req.method === 'POST' && action === 'run') {
      if (String(body.input || '').length > 8000) return fail(res,400,'Input must be 8,000 characters or less.','INPUT_TOO_LONG');
      try { const run=await executeAgent(agent,user.id,String(body.input || '').trim()); return json(res,200,{run}); }
      catch(error) { return json(res,502,{error:String(error.message || 'Agent run failed.'),code:error.code || 'RUN_FAILED',runId:error.runId}); }
    }
  }
  if (req.method === 'GET' && path === '/api/runs') {
    const { rows } = await pool.query('SELECT r.*,a.name AS agent_name FROM runs r JOIN agents a ON a.id=r.agent_id WHERE r.user_id=$1 ORDER BY r.created_at DESC LIMIT 50',[user.id]); return json(res,200,{runs:rows.map(row=>({...rowRun(row),agentName:row.agent_name}))});
  }
  if (req.method === 'GET' && path === '/api/connections') {
    const { rows }=await pool.query('SELECT provider,label,connected_at FROM connections WHERE user_id=$1 ORDER BY connected_at DESC',[user.id]);
    return json(res,200,{connections:rows.map(row=>({provider:row.provider,label:row.label,connectedAt:row.connected_at})),catalog:[
      {id:'openai',name:'OpenAI',category:'AI models',availability:'ready',description:'Run GPT agents with your own API key.'},
      {id:'anthropic',name:'Anthropic Claude',category:'AI models',availability:'ready',description:'Run Claude agents with your own API key.'},
      {id:'gemini',name:'Google Gemini',category:'AI models',availability:'ready',description:'Run Gemini agents with your own API key.'},
      {id:'whatsapp',name:'WhatsApp Business',category:'Messaging',availability:'setup_required',description:'Connect a WhatsApp Business Cloud API account.'},
      {id:'google',name:'Google Workspace',category:'Productivity',availability:'coming_soon',description:'Gmail, Calendar, and Drive via Google OAuth.'},
      {id:'slack',name:'Slack',category:'Messaging',availability:'coming_soon',description:'Workspace OAuth connection.'},
      {id:'discord',name:'Discord',category:'Messaging',availability:'coming_soon',description:'Bot and server connection.'},
      {id:'telegram',name:'Telegram',category:'Messaging',availability:'coming_soon',description:'Telegram Bot API connection.'},
      {id:'notion',name:'Notion',category:'Productivity',availability:'coming_soon',description:'Notion OAuth connection.'},
      {id:'webhook',name:'Custom webhook',category:'Developer tools',availability:'coming_soon',description:'Bring an HTTPS API with a scoped secret.'},
    ]});
  }
  const aiKeyRoute = /^\/api\/connections\/ai\/([a-z-]+)$/.exec(path);
  if (req.method === 'POST' && (aiKeyRoute || path === '/api/connections/openai')) {
    const provider = aiKeyRoute?.[1] || 'openai';
    if (!supportedProviders.has(provider)) return fail(res,404,'AI provider is not supported.','PROVIDER_NOT_SUPPORTED');
    const key=String(body.apiKey || '').trim(); const label=String(body.label || 'Personal key').trim().slice(0,80) || 'Personal key';
    const valid = provider === 'openai' ? /^sk-[A-Za-z0-9_-]{20,}$/.test(key)
      : provider === 'anthropic' ? /^sk-ant-[A-Za-z0-9_-]{20,}$/.test(key)
        : /^AIza[A-Za-z0-9_-]{20,}$/.test(key);
    if (!valid) return fail(res,400,provider === 'openai' ? 'Enter a valid OpenAI API key.' : provider === 'anthropic' ? 'Enter a valid Anthropic key beginning with sk-ant-.' : 'Enter a valid Google AI API key beginning with AIza.','INVALID_API_KEY');
    await pool.query('INSERT INTO connections(user_id,provider,label,encrypted_credentials) VALUES($1,$2,$3,$4) ON CONFLICT(user_id,provider,label) DO UPDATE SET encrypted_credentials=EXCLUDED.encrypted_credentials,connected_at=now()', [user.id,provider,label,seal({apiKey:key})]);
    return json(res,201,{connection:{provider,label,connected:true}});
  }
  if (req.method === 'POST' && path === '/api/connections/whatsapp') {
    const phoneNumberId=String(body.phoneNumberId || '').trim(); const accessToken=String(body.accessToken || '').trim(); const appSecret=String(body.appSecret || '').trim(); const verifyToken=String(body.verifyToken || '').trim();
    if (!/^\d{5,32}$/.test(phoneNumberId) || accessToken.length<20 || accessToken.length>4096 || appSecret.length<16 || appSecret.length>256 || verifyToken.length<16 || verifyToken.length>256) return fail(res,400,'Add a valid phone number ID, access token, app secret, and verify token of at least 16 characters.','INVALID_WHATSAPP_CREDENTIALS');
    const version=/^v\d{1,2}\.0$/.test(whatsappVersion)?whatsappVersion:'v23.0';
    try {
      const check=await fetch(`https://graph.facebook.com/${version}/${phoneNumberId}?fields=id,display_phone_number,verified_name`,{headers:{authorization:`Bearer ${accessToken}`},signal:AbortSignal.timeout(15_000)});
      const result=await check.json().catch(()=>({}));
      if(!check.ok || result.id!==phoneNumberId) return fail(res,502,result.error?.message || 'Meta could not verify that phone number and token. Check the number ID and WhatsApp permissions.','WHATSAPP_VERIFY_FAILED');
      const label=String(result.verified_name || result.display_phone_number || 'WhatsApp Business').slice(0,80);
      await pool.query('INSERT INTO connections(user_id,provider,label,encrypted_credentials) VALUES($1,$2,$3,$4) ON CONFLICT(user_id,provider,label) DO UPDATE SET encrypted_credentials=EXCLUDED.encrypted_credentials,connected_at=now()',[user.id,'whatsapp',label,seal({phoneNumberId,accessToken,appSecret,verifyToken,graphVersion:version})]);
      return json(res,201,{connection:{provider:'whatsapp',label,connected:true},webhookUrl:`${publicUrl || `https://${req.headers.host}`}/api/webhooks/whatsapp/${user.id}`,verifyToken});
    } catch(error) { return fail(res,502,'Could not reach Meta to verify this WhatsApp connection.','WHATSAPP_PROVIDER_UNAVAILABLE'); }
  }
  if (req.method === 'DELETE' && path.startsWith('/api/connections/')) {
    const provider=decodeURIComponent(path.slice('/api/connections/'.length)); await pool.query('DELETE FROM connections WHERE user_id=$1 AND provider=$2',[user.id,provider]); return json(res,200,{ok:true});
  }
  return fail(res,404,'Route not found.','NOT_FOUND');
}

async function serveWeb(path, res) {
  const clean = normalize(decodeURIComponent(path)).replace(/^(\.\.[/\\])+/, '').replace(/^[/\\]+/, '');
  let file = join(webRoot, clean || 'index.html');
  try { if ((await stat(file)).isDirectory()) file=join(file,'index.html'); } catch {}
  try { const data=await readFile(file); res.writeHead(200,{'content-type':MIME[extname(file)] || 'application/octet-stream','cache-control':extname(file)==='.html'?'no-cache':'public, max-age=3600','x-content-type-options':'nosniff'}); return res.end(data); }
  catch { try { const data=await readFile(join(webRoot,'index.html')); res.writeHead(200,{'content-type':MIME['.html'],'cache-control':'no-cache','x-content-type-options':'nosniff'}); return res.end(data); } catch { return json(res,503,{error:'Web client has not been built yet. Run npm run build:web.',code:'WEB_NOT_BUILT'}); } }
}

async function workLoop() {
  const client=await pool.connect(); let locked=false;
  try {
    const lock=await client.query("SELECT pg_try_advisory_lock(hashtext('v-agent-builder-scheduler')) AS locked");
    if (!lock.rows[0].locked) return;
    locked=true;
    try {
      const queue=await client.query("SELECT e.*,c.encrypted_credentials,a.* FROM whatsapp_events e JOIN connections c ON c.user_id=e.user_id AND c.provider='whatsapp' JOIN agents a ON a.user_id=e.user_id AND a.source='whatsapp' AND a.status='active' WHERE e.status='pending' ORDER BY e.created_at LIMIT 1 FOR UPDATE OF e SKIP LOCKED");
      if(queue.rows[0]) {
        const event=queue.rows[0];
        const rate=await client.query("SELECT count(*)::int AS tenant_count,count(*) FILTER (WHERE sender=$2 AND created_at>now()-interval '1 hour')::int AS sender_count FROM whatsapp_events WHERE user_id=$1 AND created_at>now()-interval '24 hours'",[event.user_id,event.sender]);
        if(rate.rows[0].tenant_count>=100 || rate.rows[0].sender_count>=10) { await client.query("UPDATE whatsapp_events SET status='ignored' WHERE event_id=$1",[event.event_id]); return; }
        await client.query("UPDATE whatsapp_events SET status='processing' WHERE event_id=$1",[event.event_id]);
        try {
          const credentials=unseal(event.encrypted_credentials); const agent={id:event.id,name:event.name,description:event.description,instructions:event.instructions,model:event.model};
          const run=await executeAgent(agent,event.user_id,event.message);
          const sent=await fetch(`https://graph.facebook.com/${credentials.graphVersion}/${credentials.phoneNumberId}/messages`,{method:'POST',headers:{authorization:`Bearer ${credentials.accessToken}`,'content-type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',to:event.sender,type:'text',text:{body:run.output.slice(0,4096)}}),signal:AbortSignal.timeout(20_000)});
          if(!sent.ok) throw new Error('The AI reply was created, but Meta could not deliver the WhatsApp message.');
          await client.query("UPDATE whatsapp_events SET status='succeeded' WHERE event_id=$1",[event.event_id]); return;
        } catch(error) { await client.query("UPDATE whatsapp_events SET status='failed' WHERE event_id=$1",[event.event_id]); console.error('whatsapp_event_failed',String(error.message || 'unknown').slice(0,200)); return; }
      }
      const due=await client.query("UPDATE agents SET next_run_at=now()+make_interval(mins=>schedule_minutes),updated_at=now() WHERE id=(SELECT id FROM agents WHERE status='active' AND source='schedule' AND next_run_at<=now() ORDER BY next_run_at LIMIT 1 FOR UPDATE SKIP LOCKED) RETURNING *");
      if (due.rows[0]) { const agent=due.rows[0]; await executeAgent(agent,agent.user_id,'Scheduled agent check-in. Review your instructions and provide a useful update.'); }
    } finally { await client.query("SELECT pg_advisory_unlock(hashtext('v-agent-builder-scheduler'))"); locked=false; }
  } catch(error) { console.error('scheduler_error', String(error.message || 'unknown').slice(0,200)); }
  finally { if(locked) await client.query("SELECT pg_advisory_unlock(hashtext('v-agent-builder-scheduler'))").catch(()=>{}); client.release(); }
}

const server=createServer(async(req,res)=>{
  res.setHeader('x-content-type-options','nosniff'); res.setHeader('x-frame-options','DENY'); res.setHeader('referrer-policy','strict-origin-when-cross-origin'); res.setHeader('permissions-policy','camera=(), microphone=(), geolocation=()');
  const origin=req.headers.origin; if (origin && (publicUrl ? origin===publicUrl : checkOrigin(req))) { res.setHeader('access-control-allow-origin',origin); res.setHeader('access-control-allow-credentials','true'); res.setHeader('vary','Origin'); }
  try { await route(req,res,new URL(req.url,'http://localhost')); }
  catch(error) { console.error('request_error', req.method, new URL(req.url,'http://localhost').pathname, String(error.message || 'unknown').slice(0,240)); if (!res.headersSent) fail(res,500,'The server could not complete this request.','INTERNAL_ERROR'); else res.end(); }
});
await pool.query('SELECT 1');
const schema=await readFile(join(ROOT,'schema.sql'),'utf8'); await pool.query(schema);
server.listen(PORT,'0.0.0.0',()=>console.log(`V-Agent Builder server listening on ${PORT}`));
const worker=setInterval(workLoop,15_000); worker.unref();
for (const signal of ['SIGTERM','SIGINT']) process.on(signal,()=>{clearInterval(worker);server.close(()=>pool.end(()=>process.exit(0)));});
