import { randomBytes } from 'node:crypto';
import { access, writeFile } from 'node:fs/promises';
import { constants } from 'node:fs';

const target = new URL('../.env', import.meta.url);
try { await access(target, constants.F_OK); console.log('An app .env file already exists. It was left unchanged.'); process.exit(0); } catch {}
const postgresPassword = randomBytes(24).toString('base64url');
const encryptionKey = randomBytes(32).toString('base64');
const env = `POSTGRES_PASSWORD=${postgresPassword}\nAPP_ENCRYPTION_KEY=${encryptionKey}\nNODE_ENV=production\nPUBLIC_APP_URL=http://localhost:4100\n`;
await writeFile(target, env, { flag:'wx', mode:0o600 });
console.log('Created a private app .env with generated database and credential-encryption secrets.');
