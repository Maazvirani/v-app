# Security operations

V-Agent Builder is designed for a private, self-hosted deployment. Keep it behind HTTPS before connecting provider accounts or exposing it to the public internet.

## Secrets

- Keep `.env`, `.env.local`, PostgreSQL backups, and `APP_ENCRYPTION_KEY` private.
- Do not commit environment files or print API keys in logs.
- Back up `APP_ENCRYPTION_KEY` separately from database backups. Rotating or losing it requires re-encrypting or replacing every saved provider credential.
- Use per-user OpenAI project keys where possible. Revoke keys that are no longer needed.

## Access

- Use long unique passwords (12 characters minimum).
- Use a trusted reverse proxy that provides TLS, request logging with secret redaction, and rate limits for account creation and sign-in.
- Keep PostgreSQL on a private network. The included compose file does not publish its database port.
- Schedule frequent database backups and confirm that a restore works before relying on the service.

## Release readiness

Before a public launch, add email verification, password reset, abuse reporting, data export/deletion, privacy and terms pages, OAuth app registrations and reviews, provider webhook signature validation, monitoring, billing controls, and an independent security review. Set account deletion and retention policies for conversation inputs and outputs.
